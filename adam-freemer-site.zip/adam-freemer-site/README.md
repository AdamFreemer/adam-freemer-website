# Adam Freemer Personal Site

Single-page dark-themed personal site for adamfreemer.com, built around a résumé-first home page with secondary sections for projects, music, and pottery. Cobalt and amber palette, sharp 22-degree geometric language throughout.

## Contents

```
adam-freemer-site/
├── README.md          this file
├── index.html         production HTML (uses /assets paths)
├── mockup.html        self-contained preview (base64 images, opens locally without a server)
├── favicon.svg        cobalt + amber AF favicon
├── og-image.jpg       1200x630 social share card
└── assets/
    ├── headshot.jpg   profile photo
    ├── studio.jpg     music studio photo
    └── pottery-01..10.jpg   ten pottery photos (lead piece first)
```

## Quick preview

Double-click `mockup.html`. It is fully self-contained, no server needed.

To work with `index.html` locally, serve from this directory:

```bash
python3 -m http.server 8000
# or
npx serve .
```

Open http://localhost:8000.

## Deploy

Recommended: Vercel (free tier, custom domain support, deploys in under a minute).

```bash
npm i -g vercel
vercel deploy --prod
```

Then point adamfreemer.com at the Vercel project via DNS.

Alternatives that work identically: Netlify, Cloudflare Pages, GitHub Pages, S3 + CloudFront.

### Post-deploy verification

1. Confirm `https://www.adamfreemer.com/og-image.jpg` returns the social share image. The Open Graph meta tags hardcode this absolute URL.
2. Paste the live URL into LinkedIn Post Inspector (linkedin.com/post-inspector) and Twitter Card Validator. Both will cache previews aggressively, so flush them on first deploy.
3. Hit ⌘+P from the Home view and verify the print preview shows a clean black-on-white résumé with the Music and Pottery sections hidden.
4. Check that the Résumé.pdf button in the hero opens the correct Dropbox URL. Update the href in `index.html` if the file moves.
5. Run Lighthouse from Chrome DevTools. Target green on Performance, Accessibility, Best Practices, SEO.

## Design system

### Color palette

```css
--bg:        #0c0e12   /* deep ink background */
--bg-2:      #13161c   /* alt section background */
--card:      #181c24   /* card surface */
--ink:       #ecebe4   /* primary text, off-white */
--ink-soft:  #a4a59f   /* secondary text */
--ink-faint: #5d6168   /* tertiary text, dates */

--cobalt:      #2a5cf0   /* primary accent: geometry, bullets, monogram, tab indicator */
--cobalt-2:    #1c46c9   /* hover state */
--cobalt-deep: #143396   /* hero sliver */

--amber:       #f59e0b   /* secondary accent: labels, company names, Present status, Résumé CTA */
--amber-2:     #fbbf24   /* hover state */
```

Rule of thumb: cobalt does structural work (large blocks, primary actions, navigation). Amber does metadata work (labels, badges, "Present" status, company names in the timeline).

### Typography

| Use | Family | Weights |
|---|---|---|
| Display + body | Hanken Grotesk | 400 / 500 / 600 / 700 / 800 / 900 |
| Mono labels, dates, metadata | JetBrains Mono | 400 / 500 / 600 |

Both load from Google Fonts.

The name in the hero renders at Hanken Grotesk Black (900). Section titles at 800. Job titles at 700. Body at 400. Avoid mixing in other display fonts; Hanken handles every weight needed.

### Geometric language

The hero uses three `clip-path` polygons at a 22-degree lean: a large cobalt block on the right, a deep cobalt sliver behind it, and an amber wedge in the bottom-right. The angle of the lean was calibrated so the top edge of each shape shifts right relative to the bottom.

All `.btn` buttons mirror this lean via a `::before` pseudo-element with `transform: skewX(-22deg)`. The pseudo holds the background and border; text content stays upright inside the rectangular bounding box so legibility is not affected.

Card corners and chips are square (0 radius). No curves anywhere.

### Spacing

- Container max-width: **1140px**
- Section vertical padding: **84px** desktop, scales down responsively
- Hero min-height: **560px**
- Sticky nav height: **~72px**, with `html { scroll-padding-top: 78px }` so anchors do not slide behind it

## Technical architecture

Single static HTML file. No framework, no build step, no transpilation. Vanilla CSS with CSS variables and vanilla JavaScript.

### How navigation works

The topbar has four anchor links: Home, Projects, Music, Pottery. Each points to a section id (`#home`, `#projects`, etc.) via real `<a href>` so browser-native scrolling works without JavaScript.

With JS enabled, two enhancements run:

1. Click intercept upgrades anchor jumps to smooth scrolls (`scrollIntoView({behavior:"smooth"})`).
2. A rAF-throttled scroll listener walks the four section ids and finds whichever one has the most recent `getBoundingClientRect().top` above the nav line. That section's tab gets the `active` class.

This intentionally avoids `IntersectionObserver` complexity. The scroll handler is cheap and reliable.

### Print stylesheet

`@media print` rules produce a clean recruiter-grade résumé suitable for paper or save-as-PDF.

- **Shown:** name, intro, contact buttons, stack, experience timeline (with job-skill chips), education, projects
- **Hidden:** topbar, hero geometric blocks, portrait, music section, pottery section, footer decoration
- Buttons un-skew to plain bordered rectangles
- All accent colors flatten to black and grays
- External URLs print after their link text so a paper copy preserves references

Test from the Home view via ⌘+P.

### Meta tags and structured data

The `<head>` contains:

- Standard SEO: `title`, `meta description`, `theme-color`, favicon
- Open Graph: full set of `og:` properties pointing to og-image.jpg
- Twitter Card: `summary_large_image` variant
- JSON-LD: `Person` schema with `jobTitle`, `worksFor`, `alumniOf`, `address`, `knowsAbout` (every tech in the stack), `sameAs` (GitHub, LinkedIn, SoundCloud, Beatport, Instagram), and `email`

The JSON-LD is invisible to humans but machine-readable for ATS systems, Google's knowledge graph, and AI agents indexing personal sites.

## Editing content

All copy lives in `index.html`. Search the file for the visible string and edit in place. No external content files.

Notable locations:

- **Hero intro line:** the "thoughtful and empathetic" sentence near the top
- **Stack rows:** four `.stack-row` blocks for Languages, Frameworks, Platforms & Infra, Approach
- **Job entries:** seven `.job` blocks in chronological reverse. Each has role, client, dates, description, optional bullet list, and a `.job-skills` chip row at the bottom
- **Education:** General Assembly and Penn State entries
- **Projects:** five `.card-proj` cards including the AI Intake Bot
- **Music:** the summary paragraph and three platform link buttons
- **Pottery:** masonry gallery wired to `assets/pottery-01..10.jpg`

The Résumé.pdf link points at a Dropbox URL. Update the href when the source moves.

### Replacing photos

To swap a photo, drop a new file into `assets/` with the same filename and the page will pick it up. Recommended specs:

- **Headshot:** roughly square or 5:6 portrait, at least 1000px on the long side, JPG
- **Studio:** landscape, at least 1600px wide, JPG
- **Pottery:** any orientation, at least 1300px on long side, JPG. The first photo is featured as the wide lead image at the top of the gallery; the other nine flow in a 3-column masonry

To add or remove pottery photos, edit the `.masonry` block in `index.html` and adjust the file references.

### Updating the OG image

The OG image (`og-image.jpg`, 1200x630) is the social share card. To regenerate after content changes, recreate the JPG at the same dimensions and replace it. The hero composition is: cobalt parallelogram block on the right with portrait inside an amber-offset frame, big white name on the left, mono caption at the bottom.

## Known limitations and future ideas

- **No analytics.** Add Plausible, Fathom, Vercel Analytics, or GA4 if traffic insight is wanted.
- **No contact form.** The hero CTA is `mailto:` which works but does not capture data. Add Formspree, Tally, or Resend if structured inquiry capture is needed.
- **No CMS.** All edits touch HTML directly. If frequent content updates become annoying, consider porting to Astro with markdown content files. The current single-file design is easy enough that this is not urgent.
- **Static OG image.** A fancier setup could generate it per-section dynamically with Vercel OG / Satori. For a personal site the static card is sufficient.
- **Pottery section is image-heavy.** Roughly 2MB of JPEGs load on the pottery section. Acceptable given they only load when scrolled to (browsers handle this), but could be lazy-loaded with `loading="lazy"` if needed (it is not currently set).

## Credit

Designed and built with Claude (Anthropic). Code is yours, no attribution required.
